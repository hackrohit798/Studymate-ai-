# StudyMate AI

A beginner-friendly study companion prototype for the **Build, Ship, Shape: Amazon Developer Hackathon**.

## Proposed hackathon entry

- **Primary track:** Alexa+ — simulated Alexa+ experience in a web app.
- **Mini-challenge:** AWS Builder — Amazon Bedrock integration.
- **Project goal:** Help students plan a study session, understand a topic, and practice retrieval with questions.
- **Hardware:** No physical Amazon device is required for the local web demo.
- **Important:** This is a proposed track mapping, not a guarantee of eligibility. Check the live official rules and any track-specific requirements before submission.

## Features

- Study-plan generator with adjustable session length.
- Beginner-friendly concept explanation mode.
- Practice-question mode.
- Responsive web UI.
- Local demo mode works without AWS credentials.
- Optional Amazon Bedrock integration through the AWS SDK (`boto3`).
- Server-side API calls; AWS credentials are never sent to the browser.
- Input validation and a local fallback if the Bedrock request fails.

## Architecture

```text
Browser (HTML/CSS/JavaScript)
          |
          | POST /api/study
          v
      Flask app
       /      \
      /        \
Local demo    Amazon Bedrock Runtime
fallback      Converse API (optional)
```

The UI sends a topic, mode, level, and study time to Flask. Flask validates the request. If Bedrock is enabled and configured, the backend calls the Bedrock Converse API and parses the model's JSON response. Otherwise it returns a deterministic local demo response.

## Requirements

- Python 3.10 or newer
- pip
- A modern browser
- Optional for AWS mode: an AWS account, AWS credentials configured locally, access to Amazon Bedrock, and a model ID supported in your chosen region.

## Run locally (no AWS account needed for demo mode)

### Windows (PowerShell)

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python app.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000.

The local mode is suitable for checking the interface and the end-to-end flow. It uses templates rather than a live language model.

## Enable Amazon Bedrock

1. Sign in to your AWS account and choose a region where the model you intend to use is available.
2. In the Amazon Bedrock console, check model availability and complete any required model-access steps for your account.
3. Configure AWS credentials using an approved local method, such as an AWS CLI profile or environment variables. Never paste credentials into source code or the browser.
4. Copy `.env.example` to `.env` and set:

```dotenv
USE_BEDROCK=true
AWS_REGION=us-east-1
BEDROCK_MODEL_ID=YOUR_ENABLED_MODEL_ID
```

Replace `YOUR_ENABLED_MODEL_ID` with a model ID actually available to your account and region. Do not assume the example region supports every model.

5. Ensure the identity used by boto3 has permission to invoke the selected model (for example, the necessary `bedrock:InvokeModel` permission for the model and API used).
6. Restart the app and try the same topic. The result label should say `Amazon Bedrock` when the live call succeeds.

If Bedrock is unavailable, the app intentionally falls back to local demo mode and displays a notice. Check the server terminal for details. Do not publish AWS keys, `.env`, account IDs, or sensitive logs.

## Example demo script (under 3 minutes)

1. **0:00–0:20 — Problem:** Students often have limited time and don't know how to structure a study session.
2. **0:20–0:50 — Study plan:** Enter “Object-oriented programming”, choose 30 minutes, and generate a plan.
3. **0:50–1:20 — Explain:** Switch to concept explanation and enter “Encapsulation in C++”.
4. **1:20–1:45 — Quiz:** Generate practice questions for the same topic.
5. **1:45–2:15 — AWS integration:** If configured, show the `Amazon Bedrock` source label and briefly explain the server-side Converse API call. Never show credentials.
6. **2:15–2:45 — Impact and limits:** Explain how the tool helps learners structure practice, and that students should verify important facts with course materials.

Record in English if following the published hackathon submission instructions. Keep the video under three minutes.

## Implementation plan

### Phase 1 — Working prototype
- [x] Build responsive UI.
- [x] Add study-plan, explain, and quiz modes.
- [x] Add local fallback so it runs without device hardware.
- [x] Add optional Bedrock Converse API integration.
- [x] Add basic input validation and safe error messages.

### Phase 2 — Validate
- [ ] Run local mode and test all three modes.
- [ ] Configure Bedrock in a permitted AWS account and test a real model invocation.
- [ ] Check response quality and correct any misleading output.
- [ ] Capture screenshots and record the demo.
- [ ] Add your own real feedback on AWS onboarding and model behavior.

### Phase 3 — Submission
- [ ] Confirm entrant eligibility and current rules.
- [ ] Push source code to a GitHub repository.
- [ ] Keep the repository public with this license, or follow the official private-repository sharing rules.
- [ ] Add the demo video and written project description.
- [ ] Complete product feedback for every tool/API/SDK used.
- [ ] Select the Alexa+ primary track and AWS Builder mini-challenge only if the final implementation meets their rules.
- [ ] Submit before the official deadline.

## Product feedback template

Fill this in from your own testing; do not claim tests you have not performed.

- **Tool/service and purpose:** Amazon Bedrock Runtime Converse API — generate study plans, explanations, and practice questions.
- **What worked well:** [Your observations]
- **What needs improvement:** [Your observations, errors, limits, or workarounds]
- **Onboarding experience:** [Your actual setup experience]
- **Would you build with it again? Why?** [Your honest answer]

## Optional friction log template

- **Task attempted:** [Specific task]
- **Steps taken:** [What you did]
- **Expected result:** [What you expected]
- **Actual result:** [What happened]
- **Severity:** Critical / Important / Nice-to-have
- **Workaround:** [If any]
- **Suggested improvement:** [Actionable suggestion]

## Security and cost notes

- Never commit `.env` or AWS credentials.
- Use least-privilege IAM permissions.
- Model invocation can incur charges. Check current AWS pricing and monitor usage before enabling Bedrock.
- This is a hackathon prototype, not a substitute for teachers, textbooks, or verified academic resources.
- Before deploying publicly, add rate limiting, stronger request controls, tests, and an appropriate privacy notice.

## Troubleshooting

- **`ModuleNotFoundError`:** Activate the virtual environment and run `pip install -r requirements.txt`.
- **Bedrock fallback notice:** Check AWS credentials, region, model ID, model access, IAM permissions, and the Flask terminal logs.
- **Port already in use:** Set `PORT=5001` in `.env`, then restart.
- **Blank or unexpected model output:** Try a narrower topic; verify the answer independently.

## License

MIT. See [LICENSE](LICENSE).
