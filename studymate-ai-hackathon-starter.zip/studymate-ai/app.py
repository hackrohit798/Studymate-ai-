import json
import os
import re
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "").strip()
USE_BEDROCK = os.getenv("USE_BEDROCK", "false").lower() == "true"

def local_response(mode, topic, minutes, level):
    """Deterministic fallback so the app works without AWS credentials."""
    topic = topic.strip()[:160]
    try:
        minutes = max(10, min(int(minutes), 240))
    except (ValueError, TypeError):
        minutes = 30

    if mode == "plan":
        blocks = [
            ("Understand the basics", round(minutes * 0.30)),
            ("Study examples", round(minutes * 0.30)),
            ("Practice from memory", round(minutes * 0.25)),
            ("Review and note doubts", minutes - round(minutes * 0.30) - round(minutes * 0.30) - round(minutes * 0.25)),
        ]
        items = [{"task": name, "minutes": max(1, mins)} for name, mins in blocks]
        return {
            "title": f"{minutes}-minute study plan: {topic}",
            "summary": f"A practical {level.lower()}-level session for {topic}.",
            "items": items,
            "tip": "After each section, close your notes and explain the idea in your own words."
        }

    if mode == "quiz":
        return {
            "title": f"Practice questions: {topic}",
            "summary": "These starter questions help you check understanding. They are general prompts, not verified textbook answers.",
            "items": [
                {"question": f"What is {topic}? Explain it in your own words.", "answer": "Try a one- or two-sentence definition, then compare it with your notes."},
                {"question": f"Why is {topic} useful? Give one example.", "answer": "Connect the concept to a practical example from your class or textbook."},
                {"question": f"What is one common mistake or misconception about {topic}?", "answer": "Identify the mistake, explain why it happens, and write the correct idea."},
            ]
        }

    return {
        "title": f"Explain: {topic}",
        "summary": f"Beginner-friendly overview of {topic}",
        "items": [
            {"heading": "Start with the idea", "text": f"Write a simple definition of {topic} in one sentence."},
            {"heading": "Connect it to an example", "text": "Use a small real-world or classroom example to make the idea concrete."},
            {"heading": "Check your understanding", "text": "Explain the idea without looking at your notes, then review any gaps."},
        ],
        "note": "Local demo mode uses a template. Connect Amazon Bedrock for generated explanations."
    }

def bedrock_response(mode, topic, minutes, level):
    # Import lazily so local mode works even if boto3 is not installed.
    import boto3
    client = boto3.client("bedrock-runtime", region_name=AWS_REGION)
    if mode == "plan":
        task = f"Create a realistic study plan for {minutes} minutes."
        schema = '{"title":"...","summary":"...","items":[{"task":"...","minutes":10}],"tip":"..."}'
    elif mode == "quiz":
        task = "Create 3 useful practice questions with short answer guidance."
        schema = '{"title":"...","summary":"...","items":[{"question":"...","answer":"..."}]}'
    else:
        task = "Explain the topic clearly using a definition, a simple example, and a quick understanding check."
        schema = '{"title":"...","summary":"...","items":[{"heading":"...","text":"..."}],"note":"..."}'

    prompt = f"""
You are StudyMate AI, a supportive educational assistant.
Topic: {topic}
Learner level: {level}
Task: {task}
Return valid JSON only, matching this structure: {schema}
Keep it age-appropriate, concise, accurate, and encouraging.
If the topic is ambiguous, state your assumption in the summary.
Do not claim the student has mastered the topic.
"""
    response = client.converse(
        modelId=BEDROCK_MODEL_ID,
        messages=[{"role": "user", "content": [{"text": prompt}]}],
        inferenceConfig={"maxTokens": 900, "temperature": 0.4, "topP": 0.9}
    )
    text = response["output"]["message"]["content"][0]["text"].strip()
    # Tolerate fenced JSON if a model returns it despite the instruction.
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.IGNORECASE)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end < start:
        raise ValueError("The model did not return valid JSON.")
    return json.loads(text[start:end + 1])

@app.get("/")
def home():
    return render_template("index.html", bedrock_ready=bool(USE_BEDROCK and BEDROCK_MODEL_ID))

@app.post("/api/study")
def study():
    data = request.get_json(silent=True) or {}
    mode = str(data.get("mode", "plan"))
    topic = str(data.get("topic", "")).strip()
    level = str(data.get("level", "Beginner")).strip()
    minutes = data.get("minutes", 30)

    if not topic:
        return jsonify({"error": "Enter a topic first."}), 400
    if len(topic) > 160:
        return jsonify({"error": "Please keep the topic under 160 characters."}), 400
    if mode not in {"plan", "quiz", "explain"}:
        return jsonify({"error": "Choose a valid study mode."}), 400
    if level not in {"Beginner", "Intermediate", "Advanced"}:
        level = "Beginner"

    if USE_BEDROCK and BEDROCK_MODEL_ID:
        try:
            result = bedrock_response(mode, topic, minutes, level)
            return jsonify({"result": result, "source": "Amazon Bedrock"})
        except Exception as exc:
            app.logger.exception("Bedrock request failed")
            # Never expose credentials or raw exception details to the browser.
            return jsonify({
                "result": local_response(mode, topic, minutes, level),
                "source": "Local fallback",
                "notice": "Bedrock could not be reached. Showing the local demo response; check server logs and AWS setup."
            })
    return jsonify({"result": local_response(mode, topic, minutes, level), "source": "Local demo"})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
